import json,boto3

clientS3 = boto3.client('s3')
clientcomprehend = boto3.client('comprehend')
clientdynamodb = boto3.client('dynamodb')
def lambda_handler(event, context):
    # TODO implement
    Key = event['Records'][0]['s3']['object']['key']
    print ('event is : {}'.format(event))
    response = clientS3.get_object(Bucket='eps24cimp001',Key=Key,)
    transcripts= json.loads(response['Body'].read().decode('utf-8'))
    text = transcripts['results']['transcripts'][0]['transcript']
    contactId = event['Records'][0]['s3']['object']['key'][0:36]
    comprehendResponse = clientcomprehend.detect_sentiment(Text=text,LanguageCode='en')
    sentiment = comprehendResponse['Sentiment']
    response = clientdynamodb.put_item(
        Item={
            'contactId': {
                'S': contactId,
            },
            'sentiment': {
                'S': sentiment,
            },
            'text': {
                'S': text,
            },
        },
        TableName='EPS24CIMP001',   
    )

    #print(response)
    #print ('comprehendResponse is:{}'.format(comprehendResponse))
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
