import json,boto3

client = boto3.client('transcribe')

def lambda_handler(event, context):
    # TODO implement
    print ('Event is : {}'.format(event))    
    contactID = event['Records'][0]['s3']['object']['key'][20:56]
    fileUri = 's3://eps24cimp001/'+event['Records'][0]['s3']['object']['key']
    newUri = fileUri.replace("%3A", ":")
    MediaFileUri =newUri.replace("%2B", "+")
    OutputKey = contactID +".json"
    response = client.start_transcription_job(
        TranscriptionJobName=contactID,
        LanguageCode='en-US',
        MediaFormat='wav',
        Media={
            'MediaFileUri': MediaFileUri,
            
        },
        OutputBucketName='eps24cimp001',
        OutputKey=OutputKey,
        
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
